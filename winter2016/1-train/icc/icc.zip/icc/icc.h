#ifndef __ICC_H__
#define __ICC_H__

void run(int);

int query(int a, int b, int *A, int *B);
void setRoad(int a, int b);

#endif // __ICC_H__

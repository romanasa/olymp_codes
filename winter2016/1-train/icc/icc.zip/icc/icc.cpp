#include "icc.h"

void run(int n) {
    int a[] = {1};
    int b[] = {2, 3};
    query(1, 2, a, b);
    setRoad(1, 2);
}
